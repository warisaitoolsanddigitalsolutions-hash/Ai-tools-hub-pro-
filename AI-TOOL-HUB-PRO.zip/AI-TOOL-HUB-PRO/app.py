from flask import Flask, render_template, request
import qrcode
import io
import base64

app = Flask(__name__)

@app.route("/")
def home():
    tools = [
        {"name": "AI Image Generator", "url": "/ai-image", "icon": "🎨"},
        {"name": "QR Code Generator", "url": "/qr-generator", "icon": "📱"},
       {"name": "AI Video Generator", "url": "/ai-video", "icon": "🎬"},
       {"name": "AI Voice Generator", "url": "/ai-voice", "icon": "🎙️"}, 
    ]
    return render_template("index.html", tools=tools)

@app.route("/qr-generator", methods=["GET", "POST"])
def qr_generator():
    qr_img = None
    if request.method == "POST":
        data = request.form["data"]
        img = qrcode.make(data)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        qr_img = base64.b64encode(buf.getvalue()).decode("utf-8")
    return render_template("qr_generator.html", qr_img=qr_img)

@app.route("/ai-image", methods=["GET", "POST"])
def ai_image():
    generated_img = None
    if request.method == "POST":
        prompt = request.form["prompt"]
        url = f"https://image.pollinations.ai/prompt/{prompt}"
        generated_img = url
    return render_template("ai_image.html", generated_img=generated_img)
@app.route("/ai-video", methods=["GET", "POST"])
def ai_video():
    video_url = None
    if request.method == "POST":
        prompt = request.form["prompt"]
        video_url = f"https://image.pollinations.ai/video/{prompt}"
    return render_template("ai_video.html", video_url=video_url)

@app.route("/ai-voice", methods=["GET", "POST"])
def ai_voice():
    audio_url = None
    if request.method == "POST":
        text = request.form["text"]
        audio_url = f"https://translate.google.com/translate_tts?ie=UTF-8&q={text}&tl=en&client=tw-ob"
    return render_template("ai_voice.html", audio_url=audio_url)
if __name__ == "__main__":
    app.run()